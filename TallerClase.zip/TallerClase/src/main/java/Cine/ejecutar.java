/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Cine;

import java.util.Scanner;

public class ejecutar {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        //-------------------
        Cliente[] clientes = null;

        int clientesAgregados = 0;
        int menu = 0;
        int subMenu = 0;
        boolean salir = false;
        //-------------------

        while (!salir) {
            menu = mostrarMenu(entrada);
            switch (menu) {
                case 1:
                    if (clientes == null) {
                        System.out.println("Digita la cantidad maxima de clientes a ingresar");
                        clientes = new Cliente[entrada.nextInt()];
                    }

                    while (!salir) {
                        subMenu = mostrarSubMenu(entrada);

                        switch (subMenu) {
                            case 1:
                                ListarClientes(clientes, clientesAgregados);
                                break;
                            case 2:
                                if (clientesAgregados < clientes.length) {
                                    clientes = agregarCliente(entrada, clientes, clientesAgregados);
                                    clientesAgregados++;
                                    ListarClientes(clientes, clientesAgregados);
                                } else {
                                    System.out.println("No es posible agregar más carros. El arreglo está lleno.");
                                }
                                break;
                            case 3:
                                salir = true;
                                break;
                            default:
                                System.out.println("Opcion no valida");
                                break;
                        }
                    }
                    salir = false;
                    break;
                case 2:
                   salir = true;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }
        }
        entrada.close();
        System.out.println("Saliendo...");
    }

    private static int mostrarMenu(Scanner entrada) {
        System.out.println("\nBienvenido al Sistema");
        System.out.println("Seleccione una opción:");
        System.out.println("1. Clientes");
        System.out.println("2. Empleados");
        System.out.println("3. Sala");
        System.out.println("4. Taquilla");
        System.out.println("5. Cafeteria");
        System.out.println("5. Salir");
        return entrada.nextInt();
    }

    private static int mostrarSubMenu(Scanner entrada) {
        System.out.println("\nMenú Clientes");
        System.out.println("Seleccione una opción:");
        System.out.println("1. Listar");
        System.out.println("2. Crear");
        System.out.println("3. Salir.");
        return entrada.nextInt();
    }

    private static void ListarClientes(Cliente[] clientes, int clientesAgregados) {
        System.out.println("\nLos clientes registrados son:");
        if (clientesAgregados == 0) {
            System.out.println("No hay carros registrados.");
        } else {
            for (int i = 0; i < clientesAgregados; i++) {
                System.out.println(clientes[i].toString());
            }
        }
    }

    private static Cliente[] agregarCliente(Scanner entrada, Cliente[] clientes, int clientesAgregados) {
        System.out.println("\nDigite la información del cliente:");

        System.out.println("Nombre:");
        String nombre = entrada.next();

        System.out.println("Numero Identificacion:");
        String identificacion = entrada.next();

        System.out.println("Telefono:");
        String telefono = entrada.next();

        Cliente cliente = new Cliente(nombre, identificacion, telefono);
        clientes[clientesAgregados] = cliente;
        System.out.println("Carro agregado correctamente.");
        return clientes;
    }

}